#!/usr/bin/perl -w
#
# Copyright (c) 2010 NVIDIA Corporation.  All rights reserved.
#
# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.  Any use, reproduction, disclosure or
# distribution of this software and related documentation without an expres
# license agreement from NVIDIA Corporation is strictly prohibited.
#

use strict;
use Getopt::Long;

my(%args);

sub print_usage
{
    my $entry;
    my @data  = ("",
                "EDIDUpdate.pl:  Tegra-Specific EDID Update Utility",
                "",
                "Usage:", 
                "", 
                "  perl EDIDUpdate.pl [action]",
                "",
                "Print Help Message",
                "   --help",
                "",
                "Load EDID",
                "   --load",
                "   --EDID=<path to EDID file>",
                "   --display=<crt|hdmi|lvds>",
                "   --module=<path to NVODM_DISP library>",
                "",
                "Extract EDID",
                "   --extract",
                "   --file=<path to file>",
                "   --display=<crt|hdmi|lvds>",
                "   --module=<path to NVODM_DISP library>");

    for $entry (@data)
    {
        print "$entry\n";
    }
    exit(1);
}

sub error_exit
{
    my $numFiles = $_[0];
    my $i;

    for ($i = 1; $i <= $numFiles; $i++)
    {
        close($_[$i]);
    }
    exit(1);
}

sub load_edid
{
    my $moduleSize = -s $args{"module"};
    my $edidSize    = -s $args{"EDID"};
    my $moduleFile = $args{"module"};
    my $disp= $args{"display"};
    my $moduleOffset;
    my @edidSize;
    my $buffInput;
    my $buffOutput;
    my $i;
    my $maxedidSize = 256;
    my $searchStr;
    my $startPos;

    # open EDID file
    open(EDID, $args{"EDID"}) or die "Can't open ", $args{"EDID"}, "...$!\n";
    binmode(EDID);
    binmode(STDOUT);

    # open driver module
    open(NVODM_DISP, "+<$moduleFile") or die "Can't open ", $args{"module"}, "..$!\n";
    binmode(NVODM_DISP);

    # read entire driver module into a buffer
    if (read(NVODM_DISP, $buffOutput, $moduleSize))
    {
        if ($disp eq "hdmi")
        {
            $searchStr = "nv-hdmi-edid";
        }
        elsif ($disp eq "crt")
        {
            $searchStr = "nv-crt-edid";
        }
        elsif ($disp eq "lvds")
        {
            $searchStr = "nv-lvds-edid";
        }
        else
        {
            print STDOUT "ERROR: Invalid disp argument:", $args{"disp"}, "!\n";
            error_exit(2, *EDID, *NVODM_DISP);
        }

        if ($buffOutput =~ /$searchStr/g)
        {
            $moduleOffset = pos($buffOutput);
            #
            # pos() will return position @ end of nv-*-edid
            #
            # Total header size is 24. Remove search string bytes to get start of EDID.
            $startPos = 24 - length($searchStr);

            # add offset to get to start of edid
            seek(NVODM_DISP, $moduleOffset + $startPos, 0);
            $moduleOffset = tell(NVODM_DISP);

            if (($edidSize > 0) && ($edidSize <= $maxedidSize)) 
            {
                if (read(EDID, $buffInput, $edidSize))
                {
                    print NVODM_DISP "$buffInput";
                }
                else
                {
                    print STDOUT "ERROR: Failed to read ", $args{"edid"}, "!\n";
                    error_exit(2, *EDID, *NVODM_DISP);
                }
            }
            else
            {
                print STDOUT "ERROR: Invalid EDID file size!\n";
                error_exit(2, *EDID, *NVODM_DISP);
            }

            # zero out the remaining bytes
            for ($i = $edidSize; $i < $maxedidSize; $i++)
            {
                print NVODM_DISP pack('U', 0);
            }
        }
        else
        {
            print STDOUT "ERROR: ", $searchStr, " not found in ", $args{"module"}, "!\n";
            error_exit(2, *EDID, *NVODM_DISP);
        }
    }
    else
    {
        print STDOUT "ERROR: Failed to read ", $args{"module"}, "!\n";
        error_exit(2, *EDID, *NVODM_DISP);
    }

    seek(EDID, 0, 0);
    seek(NVODM_DISP, $moduleOffset, 0);
    # verify that the copy succeeded
    read(EDID, $buffInput, $edidSize);
    read(NVODM_DISP, $buffOutput, $edidSize);
    if ($buffInput ne $buffOutput)
    {
        print STDOUT "ERROR: Copy mismatch!\n";
        error_exit(2, *EDID, *NVODM_DISP);
    }

    # go to begginning of size and copy size
    seek(NVODM_DISP, $moduleOffset - 4, 0);

    print NVODM_DISP pack('L', $edidSize);

    print STDOUT "EdidUpdate.pl:: EDID File loaded successfully!\n";
    close(EDID);
    close(NVODM_DISP);
}

sub extract_edid
{
    my $moduleSize = -s $args{"module"};
    my $moduleFile = $args{"module"};
    my $outputFile = $args{"file"};
    my $disp= $args{"display"};
    my $moduleOffset;
    my $buffOutput;
    my $buff;
    my @edidSize;
    my $size = 256;
    my $i;
    my $searchStr;
    my $startPos;

    # open output file
    open(EDID, ">$outputFile") or die "Can't open ", $args{"file"}, "...$!\n";
    binmode(EDID);
    binmode(STDOUT);

    # open driver module
    open(NVODM_DISP, "$moduleFile") or die "Can't open ", $args{"module"}, "..$!\n";
    binmode(NVODM_DISP);

    # read entire driver module into a buffer
    if (read(NVODM_DISP, $buffOutput, $moduleSize))
    {

        if ($disp eq "hdmi")
        {
            $searchStr = "nv-hdmi-edid";
        }
        elsif ($disp eq "crt")
        {
            $searchStr = "nv-crt-edid";
        }
        elsif ($disp eq "lvds")
        {
            $searchStr = "nv-lvds-edid";
        }
        else
        {
            print STDOUT "ERROR: Invalid disp argument:", $args{"disp"}, "!\n";
            error_exit(2, *EDID, *NVODM_DISP);
        }

        if ($buffOutput =~ /$searchStr/g)
        {
            $moduleOffset = pos($buffOutput);

            # size is found @ offset 20 from start of search string
            $startPos = 20 - length($searchStr);
            seek(NVODM_DISP, $moduleOffset + $startPos, 0);
            read(NVODM_DISP, $buff, 4);
            $size = unpack('L', $buff);

            if ($size == 0)
            {
                print STDOUT "ERROR: SW EDID not found in ", $searchStr, "\n";
                error_exit(2, *EDID, *NVODM_DISP);
            }

            # Total header size is 24. Remove search string bytes to get start of EDID.
            $startPos = 24 - length($searchStr);

            #
            # pos() will return position @ end of nv-*-edid
            # add offset to get to start of edid
            #
            seek(NVODM_DISP, $moduleOffset + $startPos, 0);

            read(NVODM_DISP, $buff, $size);
            print EDID "$buff";
        }
        else
        {
            print STDOUT "ERROR: ", $searchStr, " not found in ", $args{"module"}, "!\n";
            error_exit(2, *EDID, *NVODM_DISP);
        }
    }
    else
    {
        print STDOUT "ERROR: Failed to read ", $args{"module"}, "!\n";
        error_exit(2, *EDID, *NVODM_DISP);
    }

    print STDOUT "$outputFile created ($size bytes)!\n"; 
    close(EDID);
    close(NVODM_DISP);
}

GetOptions(\%args, "help", "load", "EDID=s", "display=s", "module=s", "extract", 
            "file=s"); 

if ($args{"help"})
{
    print_usage;
}
elsif ($args{"load"} && $args{"EDID"} && $args{"display"} &&
       $args{"module"} && $args{"extract"} && $args{"file"})
{
    extract_edid;
    load_edid;
}
elsif ($args{"load"} && $args{"EDID"} &&  $args{"display"} &&
       $args{"module"})
{
    load_edid;
}
elsif ($args{"extract"} && $args{"display"} && $args{"file"} &&
       $args{"module"})
{
    extract_edid;
}
else
{
    print_usage;
}

exit(0);

