#! /bin/sh

Usage()
{
	echo "-h : Prints this message"
	echo "-b : Selects boot device (hsmmc/nand)"
	echo "-c : Selects configblock partition only update"
	echo "-d : Selects debug boot loader without flashing"
	echo "-k : Selects kernel partition only update"
	echo "-r : Selects RAM size (256/512)"
	echo "-v : Selects colibri version (V1_1/V1_2)"
	echo "-u : Selects boot loader partition only update"
	echo "-g : Forces generation of the rootfs image file, default is to reuse the one from the last run"
	echo ""
	echo "Example \"./update.sh -r 512 -v V1_1\" flashes everything on a Colibri T20 V1.1c"
	echo "with 512MB RAM"
	echo ""
}

BOOT_DEVICE=nand
CFGBLOCK_ONLY=0
DEBUG_ONLY=0
MODVERSION=V1_2
KERNEL_ONLY=0
RAM_SIZE=256
UBOOT_ONLY=0
REGENERATE=0
#LOADER_NAND=loader.nb0
LOADER_NAND=fastboot.bin
LOADER_MMC=fastboot.bin

while getopts "b:cdghkr:v:u" Option ; do
	case $Option in
		h) Usage
			# Exit if only usage (-h) was specfied.
			if [[ $# -eq 1 ]] ; then
				exit 10
			fi
			exit 0
			;;
		b) BOOT_DEVICE=$OPTARG
			;;
		c) CFGBLOCK_ONLY=1
			;;
		d) DEBUG_ONLY=1
			;;
		g) REGENERATE=1
			;;
		k) KERNEL_ONLY=1
			;;
		r) RAM_SIZE=$OPTARG
			;;
		u) UBOOT_ONLY=1
			;;
		v) MODVERSION=$OPTARG
			;;
	esac
done

# use different u-boot binaries for hsmmc or nand, don't forget to also use the correct one in lnx_hsmmc.cfg!!
if [ ${BOOT_DEVICE} = "hsmmc" ] ; then
	LOADER=${LOADER_MMC}
	U_BOOT_BINARY=u-boot-hsmmc.bin
	BCT=../ColibriT20_333_${RAM_SIZE}_${BOOT_DEVICE}.bct
#	BCT=../ColibriT20_333_loader.bct
	IMAGEFILE=APP.ext3
fi

if [ ${BOOT_DEVICE} = "nand" ] ; then
	LOADER=${LOADER_NAND}
	U_BOOT_BINARY=u-boot.bin
	BCT=../ColibriT20_333_${RAM_SIZE}_${MODVERSION}_${BOOT_DEVICE}.bct
	IMAGEFILE=USR.yaffs2
fi

cd bin

if [ ${DEBUG_ONLY} -eq 1 ] ; then
	# Debugging only, writes only u-boot to RAM and executes it, assumes a valid BCT on target
	sudo LD_LIBRARY_PATH="$(pwd)/../nvflash" ../nvflash/nvflash --bl ${U_BOOT_BINARY} --go
	cd ..
	exit 0
fi

if [ ${CFGBLOCK_ONLY} -ne 1 ] && [ ${KERNEL_ONLY} -ne 1 ] && [ ${UBOOT_ONLY} -ne 1 ] ; then
	#delete old rootfs image file, so it gets regenerated
	[ ${REGENERATE} -eq "0" ] || sudo rm -f ${IMAGEFILE} ${IMAGEFILE}_${RAM_SIZE}_${MODVERSION}

	# Prepare full flashing
	if [ ${BOOT_DEVICE} = "nand" ] ; then
		if [ ${MODVERSION} = "V1_1" ] ; then
			PAGE_BLOCK=4k512
		fi
		if [ ${MODVERSION} = "intermediate" ] ; then
			PAGE_BLOCK=2k128
		fi
		if [ ${MODVERSION} = "V1_2" ] ; then
			PAGE_BLOCK=4k256
		fi
		#build ${IMAGEFILE} if it does not exist
		[ -e "${IMAGEFILE}_${RAM_SIZE}_${MODVERSION}" ] || sudo ../nvflash/mkyaffs2image ../rootfs ${IMAGEFILE}_${RAM_SIZE}_${MODVERSION} ${PAGE_BLOCK}
		sudo ln -sf ${IMAGEFILE}_${RAM_SIZE}_${MODVERSION} ${IMAGEFILE}
	fi

	if [ ${BOOT_DEVICE} = "hsmmc" ] ; then
		#build ${IMAGEFILE} if it does not exist
		# -b sets the maximum size of the rootfs
		[ -e "${IMAGEFILE}" ] || sudo ./genext3fs.sh -d ../rootfs -b 384 ${IMAGEFILE}
	fi

	# Full flashing
	sudo LD_LIBRARY_PATH="$(pwd)/../nvflash" ../nvflash/nvflash --bct ${BCT} --setbct --configfile  ../lnx_${BOOT_DEVICE}.cfg --create --bl ${LOADER} --go


else
	# Partial flashing
	if ([ ${CFGBLOCK_ONLY} -eq 1 ] && [ ${KERNEL_ONLY} -ne 1 ] && [ ${UBOOT_ONLY} -ne 1 ]) || ([ ${CFGBLOCK_ONLY} -ne 1 ] && [ ${KERNEL_ONLY} -eq 1 ] && [ ${UBOOT_ONLY} -ne 1 ]) || ([ ${CFGBLOCK_ONLY} -ne 1 ] && [ ${KERNEL_ONLY} -ne 1 ] && [ ${UBOOT_ONLY} -eq 1 ]) ; then
		if [ ${UBOOT_ONLY} -eq 1 ] ; then
			# U-Boot flashing
			sudo LD_LIBRARY_PATH="$(pwd)/../nvflash" ../nvflash/nvflash --bl ${LOADER} --download 4 ${U_BOOT_BINARY}
		fi
		if [ ${KERNEL_ONLY} -eq 1 ] ; then
			# Linux kernel flashing
			sudo LD_LIBRARY_PATH="$(pwd)/../nvflash" ../nvflash/nvflash --bl ${LOADER} --download 7 uImage
		fi
		if [ ${CFGBLOCK_ONLY} -eq 1 ] ; then
			# Configuration block flashing
			sudo LD_LIBRARY_PATH="$(pwd)/../nvflash" ../nvflash/nvflash --bl ${LOADER} --download 8 configblock_${RAM_SIZE}.bin
		fi
	else
		echo "Only one of -c, -k or -u is possible at any one time!"
	fi
fi
